<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="css/login.css">
    <title>Login</title>
</head>
<body>
    
    <div class="container" id="container">
        <!-- <div class="form-container sign-up">
        <form action="login_action.php" method="POST" enctype="multipart/form-data">
            <form>
                <h1>Tạo tài khoản</h1>
                <div class="social-icons">
                    <a href="#" class="icon"><i class="fa-brands fa-facebook" style="color: #005eff;"></i></a>
                    <a href="#" class="icon"><i class="fa-brands fa-google-plus-g" style="color: #ff0000;"></i></a>
                    <a href="#" class="icon"><i class="fa-brands fa-instagram" style="color: #ed0777;"></i></a>
                </div>
           
                <input type="text" placeholder="Điền tên đăng nhập" name="TenDangNhap" require>
                <input type="text" placeholder="Điền mật khẩu" name="MatKhau" require>
           
                <button name="sbmm" type="submit">Đăng ký</button>
            </form>
        </form>
        </div> -->


        <!-- đăng nhập -->


        <div class="form-container sign-in">
               <form action="login_action.php" method="post">
            <form>
                  <h1>Đăng nhập</h1>
           
                  <div class="social-icons">
                    <a href="#" class="icon"><i class="fa-brands fa-facebook" style="color: #005eff;"></i></a>
                    <a href="#" class="icon"><i class="fa-brands fa-google-plus-g" style="color: #ff0000;"></i></a>
                    <a href="#" class="icon"><i class="fa-brands fa-instagram" style="color: #ed0777;"></i></a>
                </div>
                <span>hoặc sử dụng mật khẩu email của bạn</span>
             
                <input type="text" placeholder="Username"  name ="TenDangNhap">
                <input type="password" placeholder="Password" name = "MatKhau" require>
  
                <a href="#">Forget Your Password?</a>

                <button type="submit" name="dangnhap">Đăng nhập</button>
          </form>
            </form>
        </div>


        <div class="toggle-container">
            <div class="toggle">
                <div class="toggle-panel toggle-left">
                    <h1>Chào mừng trở lại!</h1>
                    <p>Nhập thông tin cá nhân của bạn để sử dụng tất cả các tính năng của trang web</p>
                    <button class="hidden" id="login">Đăng nhập</button>
                </div>

                <div class="toggle-panel toggle-right">
                    <h1>Chào, Bạn!</h1>
                    <p>Đăng nhập với tài khoản của bạn để sử dụng tất cả các tính năng của trang web</p>
                    <!-- <button class="register" id="register">Đăng Ký</button> -->
                </div>
            </div>
        </div>
    </div>
    <!-- <script src="script.js"></script> -->
</body>
</html>
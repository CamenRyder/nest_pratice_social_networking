<?php
    $TenDangNhap = $_POST['TenDangNhap'];
    $MatKhau = $_POST['MatKhau'];

    $connect = mysqli_connect('localhost', 'root', '', 'thuexemain');

    $sql = "SELECT * FROM taikhoannhanvien WHERE TenDangNhap = '$TenDangNhap' AND MatKhau = '$MatKhau'";
    $query = mysqli_query($connect, $sql);

    if (mysqli_num_rows($query) > 0) {
        $user = mysqli_fetch_assoc($query);
        if ($user['role'] == 1) {
            // Admin user
            echo "Đăng nhập thành công (Admin)";
            header("Location: index_admin.php"); // Redirect to the admin page
        } 
        elseif ($user['role'] == 2) {
            // Regular user
            echo "Đăng nhập thành công (User)";
            header("Location: index_ketoan.php"); // Redirect to the user page
        }
    } else {
        require_once 'login.php'; // Invalid login credentials
    }
?>

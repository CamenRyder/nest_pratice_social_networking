<?php
    // $sql_brand1 = "SELECT * FROM LoaiXe";
    // $query_brand1 = mysqli_query($connect, $sql_brand1);


    $sql_query_loaixe = "SELECT LoaiXeID, TenLoaiXe FROM loaixe";
    $query_loaixe = mysqli_query($connect, $sql_query_loaixe);


    if(isset($_POST['sbm']))
    {
       $LoaiXeID =  $_POST['LoaiXeID'];
       $TenXe =  $_POST['TenXe'];
       $AnhXe =  $_POST['AnhXe'];
     

       $TinhTrangXe =  $_POST['TinhTrangXe'];
       $GiaXe =  $_POST['GiaXe'];
    
       $sql = "INSERT INTO xe(LoaiXeID,TenXe,AnhXe,TinhTrangXe, GiaXe) 
       VALUES ($LoaiXeID, '$TenXe','$AnhXe','$TinhTrangXeID',$GiaXe)";
        $query = mysqli_query($connect, $sql);
    
        header('location: ac_xe.php?page_layout=view');
    }
?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>Thêm xe mới</h2>
        </div>
        <div class="card-body">
           <form method="POST" enctype="multipart/form-data">

     
            <div class="form-group">
                <label for="">Loại xe</label>
                <select class="form-control" name="LoaiXeID" >
                      <?php
                      while($row_brand = mysqli_fetch_assoc($query_loaixe))
                      {?>
                            <option value="<?php echo $row_brand['LoaiXeID']; ?>"><?php echo $row_brand['TenLoaiXe']; ?></option>
                    <?php }
                      ?>
                </select>
            </div>
            
            <div class="from-group">
                <label for="">Tên xe</label>
                <input type="text" name="TenXe" class="form-control" required>
            </div>

               <br>
            <div class="from-group"> 
                <label for="">Link ảnh xe</label> <br>
                <input type="text" name="AnhXe" class="form-control" required>
            </div>
         <br>
         <div class="from-group">
                <label for="">Tình trạng xe</label>
                <input type="text" name="TinhTrangXe" class="form-control" required>
            </div>
          

            <div class="from-group">
                <label for="">Giá xe</label>
                <input type="number" name="GiaXe" class="form-control" required>
            </div><br>
            <button name="sbm" class="btn btn-success" type="submit">Thêm</button>
            <br>
           </form>   
            
        </div>

    </div>
</div>
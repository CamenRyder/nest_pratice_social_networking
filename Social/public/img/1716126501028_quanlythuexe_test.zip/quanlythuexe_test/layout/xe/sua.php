<?php
    $id = $_GET['id'];


    $sql_query_loaixe = "SELECT LoaiXeID, TenLoaiXe FROM loaixe";
    $query_loaixe = mysqli_query($connect, $sql_query_loaixe);



    $sql_up = "SELECT * FROM xe WHERE XeID = $id";
    $query_up = mysqli_query($connect, $sql_up);
    $row_up = mysqli_fetch_assoc($query_up);

    if(isset($_POST['sbm']))
    {
    
       $LoaiXeID =  $_POST['LoaiXeID'];
       $TenXe =  $_POST['TenXe'];

       $AnhXe =  $_POST['AnhXe'];

       $TinhTrangXe =  $_POST['TinhTrangXe'];
       $GiaXe =  $_POST['GiaXe'];

       $sql = "UPDATE xe SET LoaiXeID = $LoaiXeID ,TenXe = '$TenXe',AnhXe = '$AnhXe', TinhTrangXe = '$TinhTrangXe', GiaXe = $GiaXe WHERE XeID = $id";
        $query = mysqli_query($connect, $sql);
        header('location: ac_xe.php?page_layout=view');
    }
?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>Sửa thông tin xe</h2>
        </div>
        <div class="card-body">
           <form method="POST" enctype="multipart/form-data">


            <div class="form-group">
                <label for="">Loại Xe</label>
                <select class="form-control" name="LoaiXeID" >
                      <?php
                      while($row_brand = mysqli_fetch_assoc($query_loaixe))
                      {?>
                            <option value="<?php echo $row_brand['LoaiXeID']; ?>"><?php echo $row_brand['TenLoaiXe']; ?></option>
                    <?php }
                      ?>
                </select>
            </div>

   
            <div class="from-group">
                <label for="">Tên xe</label>
                <input type="text" name="TenXe" class="form-control" required value="<?php echo $row_up['TenXe']; ?>">
            </div>

   
            <div class="from-group">
                <label for="">Ảnh xe</label>
                <input type="text" name="AnhXe" class="form-control" required value="<?php echo $row_up['AnhXe']; ?>">
            </div>
            <br>
         
            <div class="from-group">
                <label for="">Tình trạng xe</label>
                <input type="text" name="TinhTrangXe" class="form-control" required value="<?php echo $row_up['TinhTrangXe']; ?>">
            </div>


            <div class="from-group">
                <label for="">Giá xe</label>
                <input type="number" name="GiaXe" class="form-control" required value="<?php echo $row_up['GiaXe']; ?>">
            </div>
    
            <br>
    
            <button name="sbm" class="btn btn-success" type="submit">Lưu</button>


           </form>   
            
        </div>

    </div>
</div>
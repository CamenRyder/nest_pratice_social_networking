<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $HoTen = $_POST['HoTen'];
    $CMND = $_POST['CMND'];
    $BLX = $_POST['BLX'];
    $CoQuan = $_POST['CoQuan'];
    $Email = $_POST['Email'];

    $errors = [];

    if (empty($HoTen)) {
        $errors[] = "Vui lòng nhập tên khách hàng.";
    }

    if (empty($CMND)) {
        $errors[] = "Vui lòng nhập CMND.";
    }

   

    if (empty($errors)) {
        // Thêm dữ liệu vào cơ sở dữ liệu
        $sql = "INSERT INTO khachhang (HoTen, CMND,BLX , CoQuan, Email) 
                VALUES ('$HoTen', $CMND, '$BLX', '$CoQuan', '$Email')";
        $query = mysqli_query($connect, $sql);

        if ($query) {
            header('location: ac_banggia.php');
        } else {
            echo "Có lỗi xảy ra khi thêm khách hàng.";
        }
    }
}
?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>Thêm khách hàng</h2>
        </div>
        <div class="card-body">
            <?php
            if (!empty($errors)) {
                echo '<div class="alert alert-danger"><ul>';
                foreach ($errors as $error) {
                    echo '<li>' . $error . '</li>';
                }
                echo '</ul></div>';
            }
            ?>
            <form method="POST" enctype="multipart/form-data">
                <div class="from-group">
                    <label for="">Tên khách hàng</label>
                    <input type="text" name="HoTen" class="form-control" required value="<?php echo isset($HoTen) ? $HoTen : ''; ?>">
                </div>

                <div class="from-group">
                    <label for="">CMND</label>
                    <input type="number" name="CMND" class ="form-control" required value="<?php echo isset($CMND) ? $CMND : ''; ?>">
                </div>

                <div class="from-group">
                    <label for="">BLX</label>
                    <input type="text" name="BLX" class="form-control" required value="<?php echo isset($BLX) ? $BLX : ''; ?>">
                </div>

              

                <div class="from-group">
                    <label for="">Cơ quan</label>
                    <input type="text" name="CoQuan" class="form-control" value="<?php echo isset($CoQuan) ? $CoQuan : ''; ?>">
                </div>

            <div class="from-group">
                    <label for="">Email</label>
                    <input type="email" name="Email" class="form-control" value="<?php echo isset($Email) ? $Email : ''; ?>">
                </div>

                <button name="sbm" class="btn btn-success" type="submit">Thêm</button>
            </form>   
        </div>
    </div>
</div>

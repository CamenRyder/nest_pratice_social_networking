<?php
    $sql = "SELECT * FROM khachhang";
    $query = mysqli_query($connect, $sql);
?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>Danh sách khách hàng</h2>
            <a href="index_admin.php">Home</a>
        </div>
        <div class="card-body">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th> 
                        <th>Họ tên</th> 
                        <th>CMND</th>
                        <th>BLX</th>
                        <th>Cơ quan</th>
                        <th>Email</th>
                 
                        <th>Sửa</th>
                        <!-- <th>Xóa</th> -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i = 1;
                    while($row = mysqli_fetch_assoc($query))
                    { ?>
                        <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $row['HoTen']; ?></td>
                        <td><?php echo $row['CMND'];?></td>
                        <td><?php echo $row['BLX'];?></td>
                        <td><?php echo $row['CoQuan'];?></td>
                        <td><?php echo $row['Email'];?></td>
                       
                        
                        <td>
                            <a href="ac_khachhang.php?page_layout=sua&id=<?php echo $row['KhachHangID'] ?>">Sửa</a>
                        </td>
                      
                    </tr>
                   <?php } ?>

                </tbody>
            </table>
            <a class="btn btn-primary" href="ac_khachhang.php?page_layout=them1">Thêm mới</a>
        </div>

    </div>
</div>

<script>

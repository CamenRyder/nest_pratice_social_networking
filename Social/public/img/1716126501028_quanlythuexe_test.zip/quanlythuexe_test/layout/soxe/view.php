<?php
    // Kết nối với cơ sở dữ liệu (bạn cần định nghĩa biến $connect trước đoạn mã này)
    $connect = mysqli_connect('localhost','root','','thuexemain');
    if($connect)
    {
        mysqli_query($connect, "SET NAMES 'UTF8'");
    }
    else
    {
        echo "KET NOI THAT BAI";
    }

    $sql = "SELECT * FROM hopdong";
    $query = mysqli_query($connect, $sql);
?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>Sổ xe</h2>
            <a href="index_admin.php">Home</a>
        </div>
        <div class="card-body">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th>STT</th> 
                        <th>ID xe</th> 
                        <th>Ngày thuê</th>
                        <th>Ngày trả</th>
                        <th>ID Hợp đồng</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i = 1;
                    while($row = mysqli_fetch_assoc($query))
                    { 
                        // Truy vấn để lấy thông tin từ bảng hopdong
                        $HopDongID = $row['HopDongID'];
                        $sql_hopdong = "SELECT * FROM hopdong WHERE HopDongID = $HopDongID";
                        $query_hopdong = mysqli_query($connect, $sql_hopdong);
                        $hopdong_info = mysqli_fetch_assoc($query_hopdong);

                        // Kiểm tra trạng thái hợp đồng
                        if ($hopdong_info['TinhTranghdID'] == 2) {
                            ?>
                            <tr>
                                <td><?php echo $i++; ?></td>
                                <td><?php echo $row['XeID']; ?></td>
                                <td><?php echo $hopdong_info['NgayLapHD']; ?></td>
                                <td><?php echo $hopdong_info['NgayTraXe']; ?></td>
                                <td><?php echo $hopdong_info['HopDongID'];?></td>
                            </tr>
                            <?php 
                        }
                    } 
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

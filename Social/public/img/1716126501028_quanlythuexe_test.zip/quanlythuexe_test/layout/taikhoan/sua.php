<?php
    $id = $_GET['id'];
    $sql_up = "SELECT * FROM taikhoannhanvien WHERE TaiKhoanID = $id";
    $query_up = mysqli_query($connect, $sql_up);
    $row_up = mysqli_fetch_assoc($query_up);

    if(isset($_POST['sbm']))
    {
    //    $TaiKhoanID =  $_POST['TaiKhoanID'];
       $TenDangNhap =  $_POST['TenDangNhap'];
       $MatKhau =  $_POST['MatKhau'];
       $role =  $_POST['role'];

       $sql = "UPDATE taikhoannhanvien SET TenDangNhap = '$TenDangNhap', MatKhau = '$MatKhau',role = $role WHERE TaiKhoanID = $id";
        $query = mysqli_query($connect, $sql);
        header('location: ac_taikhoan.php?page_layout=view');
    }
?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>Sửa thông tin tài khoản</h2>
        </div>
        <div class="card-body">
           <form method="POST" enctype="multipart/form-data">
            <div class="from-group">
                <label for="">Tên đăng nhập</label>
                <input type="text" name="TenDangNhap" class="form-control" required value="<?php echo $row_up['TenDangNhap']; ?>">
            </div>

            <div class="from-group">
                <label for="">Mật khẩu</label>
                <input type="text" name="MatKhau" class="form-control" required value="<?php echo $row_up['MatKhau']; ?>">
            </div>
            <div class="from-group">
                <label for="">Role </label><br>
                <label for="">1 : Admin - 2 : Kế toán</label>
                <input type="number" name="role" class="form-control" required>
            </div>
            <br>
    
            <button name="sbm" class="btn btn-success" type="submit">Lưu</button>


           </form>   
            
        </div>

    </div>
</div>
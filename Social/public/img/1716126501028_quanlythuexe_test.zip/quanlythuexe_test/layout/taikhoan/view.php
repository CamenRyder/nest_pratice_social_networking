<?php
    $sql = "SELECT * FROM taikhoannhanvien ";
    $query = mysqli_query($connect, $sql);
?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>Tài khoản nhân viên</h2>
            <a href="index_admin.php">Home</a>
        </div>
        <div class="card-body">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th> <!-- id book -->
                        <th>Tên đăng nhập</th> 
                        <th>Mật khẩu</th>
                        <th>Vai trò</th>
                        <th>Sửa</th>
                        <th>Xóa</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i = 1;
                    while($row = mysqli_fetch_assoc($query))
                    { ?>
                        <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $row['TenDangNhap']; ?></td>
                        <td><?php echo $row['MatKhau'];?></td>
                        <td><?php echo ($row['role'] == 1) ? 'Admin' : (($row['role'] == 2) ? 'Kế toán' : ''); ?></td>
                        
                        <td>
                            <a href="ac_taikhoan.php?page_layout=sua&id=<?php echo $row['TaiKhoanID'] ?>">Sửa</a>
                        </td>
                        <td>
                            <a onclick="return Del('<?php echo $row['TenDangNhap']; ?>')" href="ac_taikhoan.php?page_layout=xoa&id=<?php echo $row['TaiKhoanID'] ?>">Xóa</a>
                            
                          
                        </td> 
                    </tr>
                   <?php } ?>

                </tbody>
            </table>
            <a class="btn btn-primary" href="ac_taikhoan.php?page_layout=them">Thêm mới</a>
        </div>

    </div>
</div>

<script>

    function Del(name)
    {

        return confirm("Bạn có chắc là muốn xóa tài khoản : "+ name + " ?" );
    }

</script>

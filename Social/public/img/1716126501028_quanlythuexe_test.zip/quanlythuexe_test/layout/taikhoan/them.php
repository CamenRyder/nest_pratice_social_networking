<?php
    $sql_theloai = "SELECT * FROM taikhoannhanvien";
    $query_theloai = mysqli_query($connect, $sql_theloai);

    if(isset($_POST['sbm']))
    {
    
       $TenDangNhap =  $_POST['TenDangNhap'];
       $MatKhau =  $_POST['MatKhau'];
       $role =  $_POST['role'];
  
       $sql = "INSERT INTO taikhoannhanvien (TenDangNhap,MatKhau,role) 
       VALUES ('$TenDangNhap','$MatKhau',$role)";
        $query = mysqli_query($connect, $sql);
  
        header('location: ac_taikhoan.php?page_layout=view');
    }
?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>Thêm tài khoản</h2>
        </div>
        <div class="card-body">
           <form method="POST" enctype="multipart/form-data">

        
            <div class="from-group">
                <label for="">Tên đăng nhập</label>
                <input type="text" name="TenDangNhap" class="form-control" required>
            </div>
            <div class="from-group">
                <label for="">Mật Khẩu</label>
                <input type="text" name="MatKhau" class="form-control" required>
            </div>
            <div class="from-group">
                <label for="">Role </label><br>
                <label for="">1 : Admin - 2 : Kế toán</label>
                <input type="number" name="role" class="form-control" required>
            </div>
          <br>

            <button name="sbm" class="btn btn-success" type="submit">Thêm</button>


           </form>   
            
        </div>

    </div>
</div>
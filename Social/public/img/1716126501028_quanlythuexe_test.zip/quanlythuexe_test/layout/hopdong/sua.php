<?php
$connect = mysqli_connect('localhost', 'root', '', 'thuexemain');

if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}


$id = $_GET['id'];

// Fetch the contract details you want to process.
$sql = "SELECT *
FROM hopdong
INNER JOIN xe ON hopdong.XeID = xe.XeID
INNER JOIN khachhang ON hopdong.KhachHangID = khachhang.KhachHangID
INNER JOIN tinhtranghd ON hopdong.TinhTranghdID = tinhtranghd.TinhTranghdID
WHERE HopDongID = $id";

$query = mysqli_query($connect, $sql);
$row_up = mysqli_fetch_assoc($query);

if (isset($_POST['sbm'])) {
    $TienTra = $_POST['TienTra'];
    $TienConLai = $_POST['TienConLai'];
    $HopDongID = $_POST['HopDongID']; // Assuming you have a hidden input field for HopDongID

    // Check if TienTra is equal to TienConLai
    if ($TienTra == $TienConLai) {
        $TinhTranghdID = 2; // Contract status indicating it's completed
        $TinhTrangXeID = 1; // Vehicle status indicating it's available
        $TienConLai = 0; // No remaining payment
    } else {
        $TinhTranghdID = 1; // Contract status indicating it's not completed
        $TinhTrangXeID = 2; // Vehicle status indicating it might be in use
    }

    // Use prepared statements to prevent SQL injection
    $sql = "UPDATE hopdong SET TienTra = ?, TienConLai = ?, TinhTranghdID = ? WHERE HopDongID = ?";
    $stmt = mysqli_prepare($connect, $sql);
    mysqli_stmt_bind_param($stmt, 'ddii', $TienTra, $TienConLai, $TinhTranghdID, $HopDongID);
    mysqli_stmt_execute($stmt);

    // Update the status of the associated vehicle
    $sql_update_xe = "UPDATE xe SET TinhTrangXeID = ? WHERE XeID = (SELECT XeID FROM hopdong WHERE HopDongID = ?)";
    $stmt_update_xe = mysqli_prepare($connect, $sql_update_xe);
    mysqli_stmt_bind_param($stmt_update_xe, 'ii', $TinhTrangXeID, $HopDongID);
    mysqli_stmt_execute($stmt_update_xe);

    // Redirect to the contract list or another page
    header('location: ac_hopdong.php?page_layout=view');
}
?>


<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>Thanh toán</h2>
        </div>
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data">

             <input type="hidden" name="HopDongID" value="<?php echo $row_up['HopDongID']; ?>">
                
              <div class="form-group">
                    <label for="">Tên khách hàng</label>
                    <input type="text" name="KhachHangID" class="form-control" readonly value="<?php echo $row_up['HoTen']; ?>">
                </div>
                <div class="form-group">
                    <label for="">Xe</label>
                    <input type="text" name="XeID" class="form-control" readonly value="<?php echo $row_up['TenXe']; ?>">
                </div>
              
            
                <div class="form-group">
                    <label for="">Ngày lập hợp đồng</label>
                    <input type="date" name="NgayLapHD" class="form-control" readonly value="<?php echo $row_up['NgayLapHD']; ?>">
                </div>
                <div class="form-group">
                    <label for="">Ngày trả xe</label>
                    <input type="date" name="NgayTraXe" class="form-control" readonly value="<?php echo $row_up['NgayTraXe']; ?>">
                </div>
                <div class="form-group">
                    <label for="">Địa điểm nhận xe</label>
                    <input type="text" name="DiaDiemNhanXe" class="form-control" readonly value="<?php echo $row_up['DiaDiemNhanXe']; ?>">
                </div>
                <div class="form-group">
                    <label for="">Địa điểm trả xe</label>
                    <input type="text" name="DiaDiemTraXe" class="form-control" readonly value="<?php echo $row_up['DiaDiemTraXe']; ?>">
                </div>
                <div class="form-group">
                    <label for="">Tổng tiền</label>
                    <input type="number" name="TongTien" class="form-control" readonly value="<?php echo $row_up['TongTien']; ?>">
                </div>
                <div class="form-group">
                    <label for="">Tiền cọc</label>
                    <input type="number" name="TienCoc" class="form-control" readonly value="<?php echo $row_up['TienCoc']; ?>">
                </div>
                <div class="form-group">
                    <label for="">Tiền còn lại</label>
                    <input type="number" name="TienConLai" class="form-control" readonly value="<?php echo $row_up['TienConLai']; ?>">
                </div>
                <div class="form-group">
                    <label for="">Số tiền trả</label>
                    <input type="number" name="TienTra" class="form-control" value="<?php echo $row_up['TienTra']; ?>">
                </div>

                <br>

                <button name="sbm" class="btn btn-success" type="submit">Lưu</button>
            </form>
        </div>
    </div>
</div>

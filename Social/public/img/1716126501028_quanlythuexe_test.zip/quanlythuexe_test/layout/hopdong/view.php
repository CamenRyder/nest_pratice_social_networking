<?php
$connect = mysqli_connect('localhost','root','','thuexemain');
if($connect)
{
    mysqli_query($connect, "SET NAMES 'UTF8'");
    // echo "ket noi thanh cong";

}
else
{
    echo "KET NOI THAT BAI";
}

   $sql = "SELECT *
   FROM hopdong
   INNER JOIN xe ON hopdong.XeID = xe.XeID
   INNER JOIN khachhang ON hopdong.KhachHangID = khachhang.KhachHangID

   ORDER BY hopdong.HopDongID ASC;";
$query = mysqli_query($connect, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" >

</head>
<body>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>Danh sách hợp đồng</h2>
            <a href="index_admin.php">Home</a>
        </div>
        <div class="card-body">
            
        <a class="btn btn-primary" href="ac_hopdong.php?page_layout=them">Thêm mới</a> <br><br>
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th> 
                        <th>Tên KH</th>
                        <th>Tên xe</th> 
                        <th>Ngày lập hợp đồng </th>
                        <th>Ngày Trả xe</th>
                        <!-- <th>Địa điểm nhận xe</th>
                        <th>Địa điểm trả xe</th> -->
                        <th>Tổng tiền</th>
                        <th>Tiền cọc</th>
                        <th>Tiền còn lại</th>
                        <th>Tình trạng hợp đồng</th>
                        <th style="text-align: center;" colspan="2"> Thao tác</th>
                      
                    </tr>
                </thead>
                <tbody>
                    <?php
                  
                    while($row = mysqli_fetch_assoc($query))
                    { ?>
                        <tr>
                        <td><?php echo $row['HopDongID'];?></td>
                         <td><?php echo $row['HoTen'];?></td>
                        <td><?php echo $row['TenXe']; ?></td>

                        <td><?php echo $row['NgayLapHD'];?></td>
                        <td><?php echo $row['NgayTraXe'];?></td>
                      
                        <td><?php echo $row['TongTien']; ?></td>
                        <td><?php echo $row['TienCoc'];?></td>
                        <td><?php echo $row['TienConLai'];?></td>
                        <td><?php echo $row['TinhTrangHD'];?></td>
                        <td>    
                        
                        <a href="ac_hopdong.php?page_layout=hoadon&id=<?php echo $row['HopDongID'] ?>"><i
                            class="fas fa-print text-primary"></i></a>
                        
                 
                     
                        </td>
                       
                       <td>
                           <?php if ($row['TinhTranghdID'] != 2) { ?>
                                    <a href="ac_hopdong.php?page_layout=sua&id=<?php echo $row['HopDongID'] ?>">Thanh toán</a>
                                <?php } else { ?>
                                    <span></span>
                                <?php } ?>
                       </td>
                     

                       
                       
                    </tr>
                   <?php } ?>

                </tbody>
            </table>
 
        </div>

    </div>
</div>
 
</body>
</html>

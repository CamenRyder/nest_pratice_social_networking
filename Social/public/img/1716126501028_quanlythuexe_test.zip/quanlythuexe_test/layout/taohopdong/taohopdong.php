<?php

$sql_query_datxe = "SELECT DatXeID FROM datxe";
$query_datxe = mysqli_query($connect, $sql_query_datxe);

$sql_query_trangthaihd = "SELECT TrangThaihdID, TrangThaiHD FROM trangthaihd ";
$query_trangthaihd  = mysqli_query($connect, $sql_query_trangthaihd );


    if(isset($_POST['sbm']))
    {
    
       $DatXeID =  $_POST['DatXeID'];
       $DatXeID =  $_POST['DatXeID'];
       $sql = "INSERT INTO loaixe (TenLoaiXe) 
       VALUES ( '$TenLoaiXe')";
        $query = mysqli_query($connect, $sql);
    
        header('location: ac_loaixe.php?page_layout=view');
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Attendance Dashboard | By Code Info</title>
  <link rel="stylesheet" href="css/themloaixe.css">

  <!-- Font Awesome Cdn Link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>

<body>

  <div class="container"> 
     <nav>
      <ul>
        <li><a href="#" class="logo">
            <img src="img/user.jpg">
            <span class="nav-item">Admin</span>
          </a></li>

        <li><a href="index.php">
            <i class="fas fa-menorah"></i>
            <span class="nav-item">Trang chủ</span>
          </a></li>

        <li><a href="ac_xe.php">
            <i class="fas fa-car"></i>
            <span class="nav-item">Xe</span>
          </a></li>
        <li><a href="ac_khachhang.php">
            <i class="fas fa-users"></i>
            <span class="nav-item">Khách hàng</span>
          </a></li>
        <li><a href="#">
            <i class="fas fa-file-signature"></i>
            <span class="nav-item">Hợp đồng</span>
          </a></li>
        <li><a href="ac_taikhoan.php">
            <i class="fas fa-user-plus"></i>
            <span class="nav-item">Tài khoản</span>
          </a></li>

        <li><a href="#">
            <i class="fas fa-sign-out-alt"></i>
            <span class="nav-item">Log out</span>
          </a></li>
      </ul>
    </nav> 


<section class="main">

    <div class="main-skills">

        <div class="card">
          <a href="ac_banggia.php">
               <i class="fa-solid fa-hand-holding-dollar"></i>
          <h3>Bảng báo giá </h3>
          </a>
        </div>

        <div class="card" >
          <a href="ac_datxe.php">
            <i class="fa-solid fa-clipboard-list"></i>
          <h3>Đặt xe</h3>
          </a>
        </div>

        <div class="card">
          <a href="">
             <i class="fa-solid fa-file-signature"></i>
          <h3>Hợp đồng</h3>
          </a>
        </div>

        <div class="card">
          <a href="">
              <i class="fa-solid fa-book-tanakh"></i>
          <h3>Sổ xe</h3>
          </a>    
        </div>
      </div>
      <!--dat xe -->

      <div class="containerdatxe">
        <div class="title">Thêm loại xe</div>
        <form method="POST" enctype="multipart/form-data">
        <form action="#">
            <div class="input-box-trangthai">
              <span class="details ">Tên loại xe </span>
              <input type="text" name="TenLoaiXe" placeholder="Nhập tên loại xe" required>
            </div>  
            <button name="sbm" class="btn btn-success" type="submit">Thêm</button>

      </div>
    
      </form>
      </div>

</body>

</html>
<?php



$sql_query_kh = "SELECT * FROM khachhang";
$query_kh = mysqli_query($connect, $sql_query_kh);


$id = $_GET['id'];
$sql = "SELECT *
FROM xe 
WHERE XeID = $id";

$query = mysqli_query($connect, $sql);
$row_up = mysqli_fetch_assoc($query);

$error_message = ""; // Khởi tạo biến thông báo lỗi

if (isset($_POST['sbm'])) {
    $KhachHangID = $_POST['KhachHangID'];
    $XeID = $_POST['XeID'];
    $NgayDat = $_POST['NgayDat'];
    $NgayNhan = $_POST['NgayNhan'];
   

        $sql = "INSERT INTO datxe(KhachHangID, XeID, NgayDat, NgayNhan) 
        VALUES ('$KhachHangID', '$XeID', '$NgayDat','$NgayNhan')";
        $query = mysqli_query($connect, $sql);

        $sql_update_xe = "UPDATE xe SET TinhTrangXeID = 3 WHERE XeID = $XeID";
        $query_update_xe = mysqli_query($connect, $sql_update_xe);

        if ($query_update_xe) {
            header('location: ac_datxe.php?page_layout=view');
        } else {
            $error_message = "Có lỗi xảy ra khi cập nhật trạng thái xe.";
        }

        header('location: ac_datxe.php?page_layout=view');
    }
?>

<!-- Phần còn lại của biểu mẫu HTML -->

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>Đặt xe</h2>
        </div>
        <div class="card-body">
            <?php
            if (!empty($error_message)) {
                echo '<div class="alert alert-danger">' . $error_message . '</div>';
            }
            ?>
            <form method="POST" enctype="multipart/form-data">
                <div class="from-group">
                    <label for="">Tên khách hàng</label>
                    <select class="form-control" name="KhachHangID">
                        <?php
                        while ($row_brand = mysqli_fetch_assoc($query_kh)) {
                            echo '<option value="' . $row_brand['KhachHangID'] . '">' . $row_brand['HoTen'] . '</option>';
                        }
                        ?>
                    </select>
                </div>

                <div class="from-group">
                    <label for="">ID xe</label>
                    <input type="text" name="XeID" class="form-control" readonly value="<?php echo $row_up['XeID']; ?>">
                </div>
                <div class="from-group">
                    <label for="">Ngày đặt</label>
                    <input type="date" name="NgayDat" class="form-control" required>
                </div>
                <div class="from-group">
                    <label for="">Ngày nhận</label>
                    <input type="date" name="NgayNhan" class="form-control" required>
                </div>

                <br>

                <button name="sbm" class="btn btn-success" type="submit">Thêm</button>

            </form>
        </div>
    </div>
</div>

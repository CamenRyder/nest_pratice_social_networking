<?php
    $sql_query_loaixe = "SELECT * FROM xe";
    $query_loaixe = mysqli_query($connect, $sql_query_loaixe);
  
    $sql_query_kh = "SELECT * FROM khachhang";
    $query_kh = mysqli_query($connect, $sql_query_kh);
   


    if (isset($_POST['sbm'])) {
        $KhachHangID = $_POST['KhachHangID'];
        $XeID = $_POST['XeID'];
        $NgayDat = $_POST['NgayDat'];
        $NgayNhan = $_POST['NgayNhan'];
       

            $sql = "INSERT INTO datxe(KhachHangID, XeID, NgayDat, NgayNhan) 
            VALUES ('$KhachHangID', '$XeID', '$NgayDat','$NgayNhan')";
            $query = mysqli_query($connect, $sql);

            $sql_update_xe = "UPDATE xe SET TinhTrangXeID = 3 WHERE XeID = $XeID";
            $query_update_xe = mysqli_query($connect, $sql_update_xe);

            if ($query_update_xe) {
                header('location: ac_datxe.php?page_layout=view');
            } else {
                $error_message = "Có lỗi xảy ra khi cập nhật trạng thái xe.";
            }

            header('location: ac_datxe.php?page_layout=view');
        
    }
?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>Đặt xe</h2>
        </div>
        <div class="card-body">
        <?php
            if (!empty($error_message)) {
                echo '<div class="alert alert-danger">' . $error_message . '</div>';
            }
            ?>
           <form method="POST" enctype="multipart/form-data">

        
          
           <div class="from-group">
        
                <label for="">Tên khách hàng</label>
                <select class="form-control" name="KhachHangID" >
                      <?php
                      while($row_brand = mysqli_fetch_assoc($query_kh))
                      {?>
                            <option value="<?php echo $row_brand['KhachHangID']; ?>"><?php echo $row_brand['HoTen']; ?></option>
                    <?php }
                      ?>
                </select>
            </div>
       

            <div class="from-group">
                <label for="">Tên xe</label>
                <select class="form-control" name="XeID" >
                      <?php
                      while($row_brand = mysqli_fetch_assoc($query_loaixe))
                      {?>
                            <option value="<?php echo $row_brand['XeID']; ?>"><?php echo $row_brand['TenXe']; ?></option>
                    <?php }
                      ?>
                </select>
            </div>
            <div class="from-group">
                <label for="">Ngày đặt</label>
                <input type="date" name="NgayDat" class="form-control" required>
            </div>
            <div class="from-group">
                <label for="">Ngày nhận</label>
                <input type="date" name="NgayNhan" class="form-control" required>
            </div>
        
          <br>

            <button name="sbm" class="btn btn-success" type="submit">Thêm</button>


           </form>   
            
        </div>

    </div>
</div>
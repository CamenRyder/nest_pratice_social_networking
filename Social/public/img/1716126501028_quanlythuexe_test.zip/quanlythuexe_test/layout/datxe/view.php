<?php
$connect = mysqli_connect('localhost','root','','thuexemain');
if($connect)
{
    mysqli_query($connect, "SET NAMES 'UTF8'");
    // echo "ket noi thanh cong";

}
else
{
    echo "KET NOI THAT BAI";
}

    $sql = "SELECT *
    FROM datxe
    INNER JOIN xe ON datxe.XeID = xe.XeID
    INNER JOIN khachhang ON datxe.KhachHangID = khachhang.KhachHangID
   ";
$query = mysqli_query($connect, $sql);
?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>DS đặt xe</h2>
            <a href="index_admin.php">Home</a>
        </div>
        <div class="card-body">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th> <!-- id book -->
                        <th>Tên khách hàng</th> 
                        <th>Tên xe</th>
                       
                        <th>Ngày đặt</th>
                        <th>Ngày nhận</th>
                      
                        <th>Thao tác</th>
                       
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i = 1;
                    while($row = mysqli_fetch_assoc($query))
                    { ?>
                        <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $row['HoTen']; ?></td>
                        <td><?php echo $row['TenXe'];?></td>
                    
                        <td><?php echo $row['NgayDat'];?></td>
                        <td><?php echo $row['NgayNhanXe'];?></td>
                        

                        <td>
                            <a href="ac_hopdong.php?page_layout=them1&id=<?php echo $row['DatXeID'] ?>">Tạo hợp đồng</a>
                        </td>
                       
                    </tr>
                   <?php } ?>

                </tbody>
            </table>
            <a class="btn btn-primary" href="ac_datxe.php?page_layout=them">Thêm mới</a>
        </div>

    </div>
</div>


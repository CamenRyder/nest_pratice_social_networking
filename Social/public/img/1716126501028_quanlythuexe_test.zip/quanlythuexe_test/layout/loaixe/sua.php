<?php
    $id = $_GET['id'];
    $sql_up = "SELECT * FROM loaixe WHERE LoaiXeID = $id";
    $query_up = mysqli_query($connect, $sql_up);
    $row_up = mysqli_fetch_assoc($query_up);

    if(isset($_POST['sbm']))
    {

       $TenLoaiXe =  $_POST['TenLoaiXe'];

       $sql = "UPDATE loaixe SET TenLoaiXe = '$TenLoaiXe' WHERE LoaiXeID = $id";
        $query = mysqli_query($connect, $sql);
        header('location: ac_loaixe.php?page_layout=view');
    }
?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>Sửa thông tin loại xe</h2>
        </div>
        <div class="card-body">
           <form method="POST" enctype="multipart/form-data">
         
    
            <div class="from-group">
                <label for="">Tên loại xe</label>
                <input type="text" name="TenLoaiXe" class="form-control" required value="<?php echo $row_up['TenLoaiXe']; ?>">
            </div>
    
            <br>
    
            <button name="sbm" class="btn btn-success" type="submit">Lưu</button>


           </form>   
            
        </div>

    </div>
</div>
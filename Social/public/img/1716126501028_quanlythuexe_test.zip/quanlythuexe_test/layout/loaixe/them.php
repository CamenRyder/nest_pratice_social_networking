<?php
    $sql_loaixe = "SELECT * FROM loaixe";
    $query_loaixe = mysqli_query($connect, $sql_loaixe);

    if(isset($_POST['sbm']))
    {
    
       $TenLoaiXe =  $_POST['TenLoaiXe'];
       $sql = "INSERT INTO loaixe (TenLoaiXe) 
       VALUES ( '$TenLoaiXe')";
        $query = mysqli_query($connect, $sql);
    
        header('location: ac_loaixe.php?page_layout=view');
    }
?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>Thêm loại xe mới</h2>
        </div>
        <div class="card-body">
           <form method="POST" enctype="multipart/form-data">

            <div class="from-group">
                <label for="">Tên loại xe</label>
                <input type="text" name="TenLoaiXe" class="form-control" required>
            </div>
          

            <button name="sbm" class="btn btn-success" type="submit">Thêm</button>


           </form>   
            
        </div>

    </div>
</div>
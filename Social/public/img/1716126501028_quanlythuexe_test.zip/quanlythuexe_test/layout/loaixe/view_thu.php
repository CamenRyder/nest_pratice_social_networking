<?php
    $sql = "SELECT * FROM taikhoannhanvien ";
    $query = mysqli_query($connect, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Attendance Dashboard | By Code Info</title>
  <link rel="stylesheet" href="css/view_ds.css" />
  <!-- Font Awesome Cdn Link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>

  <div class="container">
    <nav>
      <ul>
        <li><a href="#" class="logo">
          <img src="img/user.jpg">
          <span class="nav-item">Admin</span>
        </a></li>

        <li><a href="#">
          <i class="fas fa-menorah"></i>
          <span class="nav-item">Trang chủ</span>
        </a></li>

        <li><a href="#">
          <i class="fas fa-car"></i>
          <span class="nav-item">Xe</span>
        </a></li>
        <li><a href="#">
          <i class="fas fa-users"></i>
          <span class="nav-item">Khách hàng</span>
        </a></li>
        <li><a href="#">
          <i class="fas fa-file-signature"></i>
          <span class="nav-item">Hợp đồng</span>
        </a></li>
        <li><a href="ac_taikhoan.php">
          <i class="fas fa-user-plus"></i>
          <span class="nav-item">Tài khoản</span>
        </a></li>

        <li><a href="#">
          <i class="fas fa-sign-out-alt"></i>
          <span class="nav-item">Log out</span>
        </a></li>
      </ul>
    </nav>

    <section class="main">
      <section class="attendance">
        <div class="attendance-list">
          <h4>Quản lý tài khoản</h4>
          <table class="table">
            <thead>
              <tr>
                <th>#</th>
                <th>Tên Đăng nhập</th>
                <th>Mật khẩu</th>
                <th>Sửa</th>
                <th>Xóa</th>
              
              </tr>
            </thead>
            <tbody>
              <?php
              $i = 1 ;
              while($row = mysqli_fetch_assoc($query))
              {?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $row['TenDangNhap']; ?></td>
                        <td><?php echo $row['MatKhau'];?></td>
                        
                        <td>
                            <a href="ac_taikhoan.php?page_layout=sua&id=<?php echo $row['TaiKhoanID'] ?>">Sửa</a>
                        </td>
                        <td>
                            <a onclick="return Del('<?php echo $row['TenDangNhap']; ?>')" href="ac_taikhoan.php?page_layout=xoa&id=<?php echo $row['TaiKhoanID'] ?>">Xóa</a>
                            
                          
                        </td> 
                    </tr>
                   <?php } ?>
            
            </tbody>
          </table>
          <a href="ac_taikhoan.php?page_layout=them">Thêm mới</a>
        </div>
      </section>
    </section>

  </div>
  <script>

    function Del(name)
    {

        return confirm("Bạn có chắc là muốn xóa thể loại này : "+ name + " ?" );
    }

</script>


</body>
</html>

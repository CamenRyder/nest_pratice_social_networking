<?php
    $sql = "SELECT * FROM loaixe ";
    $query = mysqli_query($connect, $sql);
?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h2>Loại xe</h2>
            <a href="index_admin.php">Home</a>
        </div>
        <div class="card-body">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        
                        <th>ID</th> 
                        <th>Tên loại xe</th>
                        <th>Sửa</th>
                    
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i = 1;
                    while($row = mysqli_fetch_assoc($query))
                    { ?>
                        <tr>
                        <td><?php echo $i++; ?></td>
                 
                        <td><?php echo $row['TenLoaiXe'];?></td>
                        <td>
                            <a href="ac_loaixe.php?page_layout=sua&id=<?php echo $row['LoaiXeID'] ?>">Sửa</a>
                        </td>
                
                        
                     
                    </tr>
                   <?php } ?>

                </tbody>
            </table>
            <a class="btn btn-primary" href="ac_loaixe.php?page_layout=them">Thêm mới</a>
        </div>

    </div>
</div>

<script>
    function Del(name)
    {
        return confirm("Bạn có chắc là muốn xóa loại xe : "+ name + " này, nếu xóa thì tất cả dữ liệu xe liên quan đến loại xe sẽ bị xóa ?" );
    }
</script>
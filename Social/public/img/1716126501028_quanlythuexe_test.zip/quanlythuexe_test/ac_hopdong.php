<?php
    require_once 'config/data.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/flatly/bootstrap.min.css" integrity="sha384-qF/QmIAj5ZaYFAeQcrQ6bfVMAh4zZlrGwTPY7T/M+iTTLJqJBJjwwnsE5Y0mV7QK" crossorigin="anonymous">
    <title>Ds hợp đồng</title>
</head>
<body>
<?php
    if(isset($_GET['page_layout']))
    {
        switch($_GET['page_layout'])
        {
           
            case 'viewquanly':
                require_once'layout/hopdong/view.php';
                break;
                case 'them':
                    require_once'layout/hopdong/them.php';
                    break;
            case 'them1':
                require_once'layout/hopdong/them1.php';
                break;
                case 'hoadon':
                    require_once'layout/hopdong/hoadon.php';
                    break;
            case 'sua':
                require_once'layout/hopdong/sua.php';
                break;
          
            default;
                require_once'layout/hopdong/view.php';
                 break;
        }
    }
    else
    {
        require_once'layout/hopdong/view.php';
    }
    ?>
</body>
</html>
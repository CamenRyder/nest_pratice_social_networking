
        <!-- giới thiệu Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                        <div class="about-img position-relative overflow-hidden p-5 pe-0">
                            <img class="img-fluid w-100" src="img/gioithieu1.jpg">
                        </div>
                    </div>
                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                        <h1 class="mb-4">#1 Mioto</h1>
                        <p class="mb-4">MIOTO là nền tảng chia sẻ ô tô, sứ mệnh của chúng tôi không chỉ dừng lại ở việc kết nối chủ xe và khách hàng một cách Nhanh chóng - An toàn - Tiện lợi, mà còn hướng đến việc truyền cảm hứng KHÁM PHÁ những điều mới lạ đến cộng đồng qua những chuyến đi trên nền tảng của chúng tôi.</p>
                        <p><i class="fa fa-check text-primary me-3"></i>An tâm đặt xe</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Giao xe tận nơi</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Dòng xe đa dạng</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Lái xe an toàn</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Thanh toán dễ dàng</p>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- giới thiệu End -->